##############################################################################################################
##############################################################################################################
## Phylogenetics workshop
## Oxalobacteriaceae example
## 2017
## Justin P. Shaffer
## justinparkshaffer@gmail.com
##############################################################################################################
##############################################################################################################

# Set working directory and install packages
##############################################################################################################
getwd()
setwd("../2017_phyloworkshop/")

install.packages("picante")
install.packages("cluster")
install.packages("dendextend")
install.packages("caper")
install.packages("ggplot2")
library(caper)
library(picante)
library(ggplot2)
library(cluster)
library(dendextend)


# Read in data files and print tree
##############################################################################################################
beta4.s<-read.csv("beta4_samp.csv", row.names=1)
beta4.t<-read.csv("beta4_trait.csv", row.names=1)
beta4.p<-read.tree("beta4.new")
beta4.p.pr<-prune.sample(beta4.s, beta4.p)
beta4.s<-beta4.s[, beta4.p.pr$tip.label]
beta4.t<- beta4.t[beta4.p.pr$tip.label, ]
plot(beta4.p, cex=0.8)
plot(beta4.p.pr, cex=0.8)

# Phylogenetic diversity
##############################################################################################################

ses.pd(beta4.s, beta4.p.pr, null.model="richness", runs=999) # within samples

# Phylogenetic signal (binar traits; D, dispersion)
##############################################################################################################

beta4.d.s<-read.csv("beta4.d_samp.csv", row.names=1)
beta4.d.t<-read.csv("beta4.d_trait.csv", row.names=1)
beta4.d.p<-read.tree("beta4.new")
beta4.d.p.pr<-prune.sample(beta4.d.s, beta4.d.p)
beta4.d.s<-beta4.d.s[, beta4.d.p.pr$tip.label]
beta4.d.t<- cbind(Taxon = rownames(beta4.d.t), beta4.d.t)
beta4.d.t<- beta4.d.t[beta4.d.p.pr$tip.label, ]
cdat<- comparative.data(data=beta4.d.t, phy=beta4.d.p.pr, names.col=Taxon)

beta4.psig.1<-phylo.d(cdat, binvar=EHB.seed.tropical)
print(beta4.psig.1)
beta4.psig.2<-phylo.d(cdat, binvar=EHB.leaf.tropical)
print(beta4.psig.2)
beta4.psig.3<-phylo.d(cdat, binvar=EHB.leaf.temperate)
print(beta4.psig.3)

# Phylogenetic beta-diversity
##############################################################################################################

beta4.phydist<-cophenetic(beta4.p.pr)
beta4.comdistnt.r<-comdistnt(beta4.s,beta4.phydist)
beta4.comdistnt.r
beta4.comdistnt.clusters<-hclust(beta4.comdistnt.r)
beta4.comdistnt.dendro<- as.dendrogram(beta4.comdistnt.clusters)
par(mar = c(3,1,3,7), lwd=5, cex=1.9)
plot(hang.dendrogram(beta4.comdistnt.dendro), horiz = TRUE, main="Oxalobacteriaceae", xlab="Mean Nearest Taxon Distance", lwd=5, cex.lab=1.25, xlim=c(.06,0))

